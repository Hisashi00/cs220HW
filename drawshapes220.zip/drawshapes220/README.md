# DrawShapes
## Basic shape drawing program for Java

## Questions for students
* Explain the class hierarchy for shapes
* How does clicking and dragging to select a shape work?

## Core features for students to add
* Save a scene to a file
* Load a scene from a file
* Undo the last action
